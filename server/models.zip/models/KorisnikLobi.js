module.exports = (sequelize , DataTypes) => {
 
    const KorisnikLobi = sequelize.define('KorisnikLobi', {

      });
 
    return KorisnikLobi;
  };